package com.example.crudcomJPA.controleDeVendas.Controller;

import com.example.crudcomJPA.controleDeVendas.Model.Cliente;
import com.example.crudcomJPA.controleDeVendas.Model.ClientePF;
import com.example.crudcomJPA.controleDeVendas.Model.Produto;
import com.example.crudcomJPA.controleDeVendas.Repository.ClientePFRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;

@Transactional
@Controller
@RequestMapping("clientes")
public class ControllerClientePF {

    @Autowired
    ClientePFRepository repository;

    @GetMapping("/cadastrar-cliente")
    public ModelAndView form(ClientePF clientePF) {
        return new ModelAndView("/clientes/form");
    }

    @GetMapping("/list")
    public ModelAndView listar(ModelMap model) {
        model.addAttribute("clientePF", repository.clientesPF());
        return new ModelAndView("/clientes/list", model);
    }

    @PostMapping("/save")
    public ModelAndView save(@Valid ClientePF cliente, BindingResult result) {
        if(result.hasErrors())
            return form(cliente);
        //para manter o objeto com dados preenchidos
        repository.save(cliente);
        return new ModelAndView("redirect:/clientes/list");
    }

    @GetMapping("/remove/{idCliente}")
    public ModelAndView remove(@PathVariable("idCliente") int idCliente) {
        repository.remove(idCliente);
        return new ModelAndView("redirect:/clientes/list");
    }

    @GetMapping("/edit/{idCliente}")
    public ModelAndView edit(@PathVariable("idCliente") int idCliente, ModelMap model) {
        model.addAttribute("clientePF", repository.clientePF(idCliente));
        return new ModelAndView("/clientes/form", model);
    }

    @PostMapping("/update")
    public ModelAndView update(ClientePF clientePF) {
        repository.update(clientePF);
        return new ModelAndView("redirect:/clientes/list");
    }

    @GetMapping("/buscarforname")
    public ModelAndView buscarforname(@RequestParam(value = "nome") String nome, ModelMap model) {
        model.addAttribute("clientePF", repository.clientes(nome));
        return new ModelAndView("/clientes/list");
    }
}
