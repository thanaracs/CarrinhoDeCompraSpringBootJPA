package com.example.crudcomJPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CruDcomSpringApplicationTests {

    @Test
    void contextLoads() {
    }

}
